import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;

public class StringReassemblyTest {

    @Test
    public void testCombination1() {
        String str1 = "Zooto";
        String str2 = "topia";
        int overlap = 2;
        String exp = "Zootopia";

        String result = StringReassembly.combination(str1, str2, overlap);

        assertEquals(result, exp);
    }

    @Test
    public void testCombination2() {
        String str1 = "Diction";
        String str2 = "ionary";
        int overlap = 3;
        String exp = "Dictionary";

        String result = StringReassembly.combination(str1, str2, overlap);

        assertEquals(result, exp);

    }

    @Test
    public void testAddToSetAvoidingSubstrings1() {
        Set<String> strSet = new Set1L<>();
        strSet.add("Comb");
        strSet.add("Combination");
        strSet.add("Dom");
        strSet.add("Domination");
        Set<String> strSetExp = new Set1L<>();
        strSetExp.add("Combination");
        strSetExp.add("Dom");
        strSetExp.add("Domination");
        strSetExp.add("Combining");

        String str = "Combining";

        StringReassembly.addToSetAvoidingSubstrings(strSet, str);

        assertEquals(strSet, strSetExp);

    }
}
