import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class InputHandler implements KeyListener, MouseListener{
	private boolean[] keys = new boolean[256];
	/**
	 * Assigns InputHandler to a Component
	 * @param c Component to get input from
	 */
	public InputHandler (Component c){
		c.addKeyListener(this);
		c.addMouseListener(this);
	}

	/** 
     * Checks whether a specific key is down 
     * @param keyCode The key to check 
     * @return Whether the key is pressed or not 
     */ 
    public boolean isKeyDown(int keyCode){
    	boolean rValue = false;
    	
    	if (keyCode > 0 && keyCode < 256){
    		rValue = keys[keyCode];
    	}
    	
		return rValue;
    }
    
    /** 
     * Called when a key is pressed while the component is focused 
     * @param e KeyEvent sent by the component 
     */ 
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() > 0 && e.getKeyCode() < 256){
			keys[e.getKeyCode()] = true;
		}
	}

	/** 
     * Called when a key is released while the component is focused 
     * @param e KeyEvent sent by the component 
     */ 
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() > 0 && e.getKeyCode() < 256){
			keys[e.getKeyCode()] = false;
		}
	}

	/** 
     * Not used 
     */ 
	public void keyTyped(KeyEvent e) {}

	@Override
	public void mouseClicked(MouseEvent e) {
		int x=e.getX();
	    int y=e.getY();
	    System.out.println(x+","+y);
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		int mx = e.getX();
		int my = e.getY();
//		int x = GameEngine.x;
//		int y = GameEngine.y;
		// bbg.drawRect(windowWidth / 2 - 20, windowHeight / 2 - 25, 100, 40);
		if (!GameEngine.isRunning){
			if (mx > (430) && mx < (535)){
				if (my > (450) && my < (490)){
					GameEngine.isRunning = true;
				}
			}
		}
		
		if (mx > (430) && mx < (535)){
    		if (my > (450) && my < (490)){
    			GameEngine.addPoint();
    		}
    	}
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
