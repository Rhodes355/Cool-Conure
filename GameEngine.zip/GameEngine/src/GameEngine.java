import java.awt.Color;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.KeyEvent;
// import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
// import java.util.Random;

import javax.swing.JFrame;

public class GameEngine extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5024743624066497330L;
	public static boolean isRunning;
	private static int fps;
	private int windowWidth;
	private int windowHeight;
	public static int x,y;
	private static int point;
	private BufferedImage backBuffer;
	private Insets insets;
	private InputHandler input;
	
	public static void main(String[] args) {
		Clicker.main(args);

	}
	
	public GameEngine (int width, int height){
		windowHeight = height;
		windowWidth = width;
	}
	
	/** 
     * Starts the game and runs it in a loop 
     */ 
    public void run() {
    	initialize();
    	while (!isRunning){
    		update();
    		draw();
    	}
        while (isRunning){
        	long time = System.currentTimeMillis();
        	
        	update();
        	draw();
        	
        	//  delay for each frame  -   time it took for one frame 
            time = (1000 / fps) - (System.currentTimeMillis() - time);
            
            if (time > 0) {
            	try { 
            		Thread.sleep(time); 
            	} catch(Exception e){} 
            } 
        }
        
        setVisible(false); 
    } 
    
    /** 
     * Set up everything need for the game to run 
     */ 
    void initialize() {
        fps = 60;
        isRunning = false;
        point = 0;
        
    	setTitle("Game Tutorial"); 
        setSize(windowWidth, windowHeight); 
        setResizable(false); 
        setDefaultCloseOperation(EXIT_ON_CLOSE); 
        setVisible(true);
        
        backBuffer = new BufferedImage(windowWidth, 
        		windowHeight, BufferedImage.TYPE_INT_RGB);
        insets = getInsets(); 
        setSize(insets.left + windowWidth + insets.right, 
                        insets.top + windowHeight + insets.bottom);
        input = new InputHandler(this);
    } 
    
    /** 
     * Check for input, move things 
     * around and check for win conditions, etc 
     */ 
    void update() { 
//    	Random rand = new Random();
//    	x = rand.nextInt(windowWidth - insets.right);
//    	y = rand.nextInt(windowHeight - insets.top);
    	
    	if (input.isKeyDown(KeyEvent.VK_BACK_SPACE)){
    		isRunning = false;
    	}
    	
    	if (input.isKeyDown(KeyEvent.VK_RIGHT)) { 
    		x += 5; 
    	} 
    	if (input.isKeyDown(KeyEvent.VK_LEFT)) {
    		x -= 5; 
    	}
    	if (input.isKeyDown(KeyEvent.VK_UP)) {
    		y -= 5; 
    	}
    	if (input.isKeyDown(KeyEvent.VK_DOWN)) {
    		y += 5; 
    	}
    } 
    
    /** 
     * This method will draw everything 
     */ 
    void draw() {
    	Graphics g = getGraphics(); 

    	Graphics bbg = backBuffer.getGraphics(); 

    	bbg.setColor(Color.WHITE); 
    	bbg.fillRect(0, 0, windowWidth, windowHeight); 
    	
    	if (!isRunning){
    		bbg.setColor(Color.BLACK); 
        	bbg.drawRect(windowWidth / 2 - 20, windowHeight / 2 - 25, 100, 40);
        	bbg.drawString("Click to start", windowWidth / 2, windowHeight / 2);
    	}
    	
    	if (isRunning){
    		bbg.setColor(Color.BLACK);
    		bbg.fillRect(windowWidth / 2 - 20, windowHeight / 2 - 25, 100, 40);
	    	bbg.drawString("Points: " + point, 20, 20);
	    	bbg.drawString("Backspace to stop game", 20, 50);
    	}

//    	bbg.setColor(Color.BLACK); 
//    	bbg.drawOval(x, y, 20, 20);
    	
    	g.drawImage(backBuffer, insets.left, insets.top, this); 
    }
    
    public static void addPoint (){
    	point++;
    }

}
