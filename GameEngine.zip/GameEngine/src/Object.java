public class Object {
	private HitBox hitbox;
	
	
	public Object(){
		hitbox = new HitBox();
	}
}
