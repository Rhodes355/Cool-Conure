
public class Clicker {

	public static void main(String[] args) {
		GameEngine game = new GameEngine(900, 900);
		
		game.run();

	}

}
